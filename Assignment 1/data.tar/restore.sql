--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 10.11
-- Dumped by pg_dump version 12.4

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE maarten;
--
-- Name: maarten; Type: DATABASE; Schema: -; Owner: maarten
--

CREATE DATABASE maarten WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'English_United States.1252' LC_CTYPE = 'English_United States.1252';


ALTER DATABASE maarten OWNER TO maarten;

\connect maarten

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: countries; Type: TABLE DATA; Schema: public; Owner: maarten
--

COPY public.countries (code, name, continent_name) FROM stdin;
\.
COPY public.countries (code, name, continent_name) FROM '$$PATH$$/4249.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: maarten
--

COPY public.users (id, full_name, created_at, country_code) FROM stdin;
\.
COPY public.users (id, full_name, created_at, country_code) FROM '$$PATH$$/4248.dat';

--
-- Data for Name: merchants; Type: TABLE DATA; Schema: public; Owner: maarten
--

COPY public.merchants (id, country_code, merchant_name, "created at", admin_id) FROM stdin;
\.
COPY public.merchants (id, country_code, merchant_name, "created at", admin_id) FROM '$$PATH$$/4253.dat';

--
-- Data for Name: orders; Type: TABLE DATA; Schema: public; Owner: maarten
--

COPY public.orders (id, user_id, status, created_at) FROM stdin;
\.
COPY public.orders (id, user_id, status, created_at) FROM '$$PATH$$/4251.dat';

--
-- Data for Name: products; Type: TABLE DATA; Schema: public; Owner: maarten
--

COPY public.products (id, name, merchant_id, price, status, created_at) FROM stdin;
\.
COPY public.products (id, name, merchant_id, price, status, created_at) FROM '$$PATH$$/4252.dat';

--
-- Data for Name: order_items; Type: TABLE DATA; Schema: public; Owner: maarten
--

COPY public.order_items (order_id, product_id, quantity) FROM stdin;
\.
COPY public.order_items (order_id, product_id, quantity) FROM '$$PATH$$/4250.dat';

--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: maarten
--

SELECT pg_catalog.setval('public.users_id_seq', 1, false);


--
-- PostgreSQL database dump complete
--

